import { useState } from "react";
import { GlowButton } from "./components/GlowButton";
import { FuturisticCard } from "./components/FuturisticCard";
import { EditableAppointmentCard } from "./components/EditableAppointmentCard";
import { RevenueChart } from "./components/RevenueChart";
import { WeekCalendar } from "./components/WeekCalendar";
import { ProfileEditModal } from "./components/ProfileEditModal";
import { NewAppointmentModal } from "./components/NewAppointmentModal";
import { NewClientModal } from "./components/NewClientModal";
import { ClientCard } from "./components/ClientCard";
import { DayCapacityModal } from "./components/DayCapacityModal";
import { NotificationsModal } from "./components/NotificationsModal";
import { SubscriptionSettings } from "./components/SubscriptionSettings";
import { Badge } from "./components/ui/badge";
import { Progress } from "./components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "./components/ui/avatar";
import { Bell, Settings, Home, Calendar, Users, BarChart3, Wifi, Battery, Scissors, Plus, Clock, Star, Edit } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState("home");
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isNewAppointmentModalOpen, setIsNewAppointmentModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isDayCapacityModalOpen, setIsDayCapacityModalOpen] = useState(false);
  const [isNotificationsModalOpen, setIsNotificationsModalOpen] = useState(false);
  const [isNewClientModalOpen, setIsNewClientModalOpen] = useState(false);
  const [hasUnreadNotifications, setHasUnreadNotifications] = useState(true);
  const [masterName, setMasterName] = useState("Мария Мастер");
  const [masterRole, setMasterRole] = useState("hairdresser");
  const [organizationName, setOrganizationName] = useState("САЛОН КРАСОТЫ");
  const [organizationIcon, setOrganizationIcon] = useState("scissors");
  const [dayCapacity, setDayCapacity] = useState(8);

  // Клиенты-шаблоны
  const [clients, setClients] = useState([
    {
      id: 1,
      name: "Елена Петрова",
      phone: "+7 (999) 123-45-67",
      telegram: "@elena_p",
      service: "Маникюр",
      price: 1500,
      initials: "ЕП"
    },
    {
      id: 2,
      name: "Игорь Дмитриев",
      phone: "+7 (987) 654-32-10",
      telegram: "",
      service: "Стрижка",
      price: 2000,
      initials: "ИД"
    }
  ]);

  // Мок-данные
  const revenueData = {
    monthData: {
      period: "Декабрь 2024",
      amount: 85000,
      change: 12,
      appointments: 42
    },
    yearData: {
      period: "2024",
      amount: 950000,
      change: 8,
      appointments: 480
    }
  };

  const [todayAppointments, setTodayAppointments] = useState([
    {
      id: 1,
      client: { name: "Елена Петрова", phone: "+7 (999) 123-45-67", telegram: "@elena_p", initials: "ЕП" },
      service: { name: "Маникюр", duration: 90, price: 1500, icon: "star" as const },
      time: "11:00",
      status: "upcoming" as const
    },
    {
      id: 2,
      client: { name: "Игорь Дмитриев", phone: "+7 (987) 654-32-10", initials: "ИД" },
      service: { name: "Стрижка", duration: 60, price: 2000, icon: "scissors" as const },
      time: "17:00", 
      status: "upcoming" as const
    }
  ]);

  const roleLabels: { [key: string]: string } = {
    hairdresser: "Парикмахер",
    tutor: "Репетитор", 
    masseur: "Массажист",
    beautician: "Косметолог",
    manicurist: "Мастер маникюра",
    trainer: "Тренер",
    psychologist: "Психолог",
    photographer: "Фотограф"
  };

  const handleProfileSave = (name: string, role: string) => {
    setMasterName(name);
    setMasterRole(role);
  };

  const handleOrganizationSave = (name: string, icon: string) => {
    setOrganizationName(name);
    setOrganizationIcon(icon);
  };

  const handleNewAppointmentSave = (appointment: any) => {
    console.log("Новая запись:", appointment);
    // Здесь будет логика сохранения записи
  };

  const handleDayCapacitySave = (capacity: number) => {
    setDayCapacity(capacity);
  };

  const handleAppointmentEdit = (appointmentId: number, data: any) => {
    setTodayAppointments(prev => 
      prev.map(apt => 
        apt.id === appointmentId 
          ? {
              ...apt,
              client: { 
                ...apt.client, 
                name: data.clientName, 
                phone: data.clientPhone, 
                telegram: data.clientTelegram 
              },
              service: { ...apt.service, name: data.service, price: data.price },
              time: data.time
            }
          : apt
      )
    );
  };

  const handleAppointmentDelete = (appointmentId: number) => {
    setTodayAppointments(prev => prev.filter(apt => apt.id !== appointmentId));
  };

  const handleAppointmentStatusChange = (appointmentId: number, status: "upcoming" | "completed" | "cancelled") => {
    setTodayAppointments(prev => 
      prev.map(apt => 
        apt.id === appointmentId ? { ...apt, status } : apt
      )
    );
  };

  const getOrganizationIconEmoji = (icon: string) => {
    const iconMap: { [key: string]: string } = {
      scissors: "✂️", palette: "🎨", sparkles: "✨", heart: "💖", crown: "👑",
      diamond: "💎", flower: "🌸", star: "⭐", beauty: "💄", spa: "🧖‍♀️",
      nail: "💅", book: "📚", music: "🎵", camera: "📸", gym: "💪", brain: "🧠"
    };
    return iconMap[icon] || "✂️";
  };

  const getCurrentLoadPercentage = () => {
    return Math.round((todayAppointments.length / dayCapacity) * 100);
  };

  const handleNotificationsClick = () => {
    setIsNotificationsModalOpen(true);
    setHasUnreadNotifications(false);
  };

  const handleNewClientSave = (clientData: any) => {
    const newClient = {
      ...clientData,
      id: Date.now(),
      initials: clientData.name.split(' ').map((n: string) => n[0]).join('').toUpperCase()
    };
    setClients(prev => [...prev, newClient]);
  };

  const handleClientEdit = (clientId: number, data: any) => {
    setClients(prev => 
      prev.map(client => 
        client.id === clientId ? { ...client, ...data } : client
      )
    );
  };

  const handleClientDelete = (clientId: number) => {
    setClients(prev => prev.filter(client => client.id !== clientId));
  };

  const renderContent = () => {
    switch (activeTab) {
      case "calendar":
        return <WeekCalendar onNewAppointment={() => setIsNewAppointmentModalOpen(true)} />;
      case "stats":
        return <RevenueChart monthData={revenueData.monthData} yearData={revenueData.yearData} />;
      case "clients":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl text-white">Клиенты</h2>
              <GlowButton 
                variant="secondary" 
                className="p-2"
                onClick={() => setIsNewClientModalOpen(true)}
              >
                <Plus className="w-4 h-4" />
              </GlowButton>
            </div>
            {clients.length === 0 ? (
              <div className="text-center py-12">
                <Users className="w-12 h-12 text-white/30 mx-auto mb-4" />
                <p className="text-white/60 mb-4">У вас пока нет клиентов</p>
                <GlowButton 
                  variant="primary"
                  onClick={() => setIsNewClientModalOpen(true)}
                >
                  Добавить первого клиента
                </GlowButton>
              </div>
            ) : (
              <div className="space-y-3">
                {clients.map((client) => (
                  <ClientCard 
                    key={client.id}
                    client={client}
                    onEdit={handleClientEdit}
                    onDelete={handleClientDelete}
                    onSelect={(selectedClient) => {
                      console.log('Выбран клиент для записи:', selectedClient);
                      // Здесь можно открыть модал записи с предзаполненными данными
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        );
      case "settings":
        return <SubscriptionSettings 
          isPaymentModalOpen={isPaymentModalOpen}
          setIsPaymentModalOpen={setIsPaymentModalOpen}
          organizationName={organizationName}
          organizationIcon={organizationIcon}
          masterName={masterName}
          masterRole={masterRole}
          onOrganizationSave={handleOrganizationSave}
          onProfileSave={handleProfileSave}
        />;
      default:
        return (
          <>
            {/* Quick Stats */}
            <div className="px-6 mb-6">
              <FuturisticCard 
                glow 
                className="p-6 relative overflow-hidden cursor-pointer hover:scale-[1.02] transition-transform"
                onClick={() => setIsDayCapacityModalOpen(true)}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-lg">{getOrganizationIconEmoji(organizationIcon)}</span>
                    <Badge variant="secondary" className="bg-white/20 text-white border-0">
                      {organizationName}
                    </Badge>
                  </div>
                  <h2 className="text-xl mb-2">Сегодня {new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}</h2>
                  <p className="text-white/70 text-sm mb-4">
                    У вас {todayAppointments.length} из {dayCapacity} записей на сегодня
                  </p>
                  <Progress value={getCurrentLoadPercentage()} className="mb-4 bg-white/20" />
                  <div className="flex justify-between text-sm text-white/60">
                    <span>Загруженность дня</span>
                    <span>{getCurrentLoadPercentage()}%</span>
                  </div>
                </div>
              </FuturisticCard>
            </div>

            {/* Action Buttons */}
            <div className="px-6 mb-6">
              <div className="grid grid-cols-2 gap-3">
                <GlowButton variant="primary" className="py-4 min-h-[80px]" onClick={() => setActiveTab("calendar")}>
                  <div className="flex flex-col items-center gap-2">
                    <Calendar className="w-6 h-6 shrink-0" />
                    <span className="text-sm text-center leading-tight">Календарь</span>
                  </div>
                </GlowButton>
                <GlowButton 
                  variant="secondary" 
                  className="py-4 min-h-[80px]"
                  onClick={() => setIsNewAppointmentModalOpen(true)}
                >
                  <div className="flex flex-col items-center gap-2">
                    <Plus className="w-6 h-6 shrink-0" />
                    <span className="text-sm text-center leading-tight">Новая запись</span>
                  </div>
                </GlowButton>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="px-6 mb-6">
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: "За месяц", value: "85K₽", color: "text-green-400" },
                  { label: "Клиенты", value: "42", color: "text-blue-400" },
                  { label: "Сегодня", value: "2", color: "text-purple-400" }
                ].map((stat, index) => (
                  <FuturisticCard key={index} className="p-4 text-center">
                    <div className={`text-lg ${stat.color} mb-1`}>{stat.value}</div>
                    <div className="text-xs text-white/60">{stat.label}</div>
                  </FuturisticCard>
                ))}
              </div>
            </div>

            {/* Today's Appointments */}
            <div className="px-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg text-white/90">Записи на сегодня</h3>
                <div className="flex items-center gap-1 text-white/60 text-sm">
                  <Clock className="w-4 h-4" />
                  <span>2 записи</span>
                </div>
              </div>
              <div className="space-y-3">
                {todayAppointments.map((appointment) => (
                  <EditableAppointmentCard 
                    key={appointment.id}
                    client={appointment.client}
                    service={appointment.service}
                    time={appointment.time}
                    status={appointment.status}
                    onEdit={(data) => handleAppointmentEdit(appointment.id, data)}
                    onDelete={() => handleAppointmentDelete(appointment.id)}
                    onStatusChange={(status) => handleAppointmentStatusChange(appointment.id, status)}
                  />
                ))}
              </div>
            </div>
          </>
        );
    }
  };

  return (
    <div className="dark min-h-screen bg-black text-white">
      {/* Mobile Container */}
      <div className="max-w-sm mx-auto bg-gradient-to-b from-gray-900 to-black min-h-screen relative overflow-hidden pb-20">
        
        {/* Background Glow Effects */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-96 h-96 bg-white/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
        
        {/* Status Bar */}
        <div className="flex justify-between items-center px-6 py-3 text-sm">
          <div className="flex items-center gap-1">
            <span>9:41</span>
          </div>
          <div className="flex items-center gap-1">
            <Wifi className="w-4 h-4" />
            <span className="text-xs">5G</span>
            <Battery className="w-4 h-4" />
            <span className="text-xs">87%</span>
          </div>
        </div>

        {/* Header */}
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Avatar 
                  className="w-10 h-10 border border-white/20 cursor-pointer hover:border-white/40 transition-colors"
                  onClick={() => setIsProfileModalOpen(true)}
                >
                  <AvatarFallback className="bg-white/10 text-white">
                    {masterName.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <button 
                  onClick={() => setIsProfileModalOpen(true)}
                  className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                >
                  <Edit className="w-3 h-3 text-white" />
                </button>
              </div>
              <div>
                <p className="text-white/60 text-sm">{roleLabels[masterRole] || "Специалист"}</p>
                <h1 className="text-white">{masterName}</h1>
              </div>
            </div>
            <div className="flex gap-2">
              <button 
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors relative"
                onClick={handleNotificationsClick}
              >
                <Bell className="w-5 h-5" />
                {hasUnreadNotifications && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full shadow-[0_0_10px_rgba(239,68,68,0.5)]"></div>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="px-6">
          {renderContent()}
        </div>

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-sm">
          <div className="bg-gray-900/80 backdrop-blur-lg border-t border-white/10 px-6 py-4">
            <div className="flex justify-around">
              {[
                { id: "home", icon: Home, label: "Главная" },
                { id: "calendar", icon: Calendar, label: "Календарь" },
                { id: "clients", icon: Users, label: "Клиенты" },
                { id: "stats", icon: BarChart3, label: "Статистика" },
                { id: "settings", icon: Settings, label: "Настройки" }
              ].map((item, index) => (
                <button
                  key={index}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all duration-300 ${
                    activeTab === item.id
                      ? 'text-white shadow-[0_0_15px_rgba(255,255,255,0.3)]' 
                      : 'text-white/60 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-xs">{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Модальные окна */}
        <ProfileEditModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          currentName={masterName}
          currentRole={masterRole}
          onSave={handleProfileSave}
        />

        <NewAppointmentModal
          isOpen={isNewAppointmentModalOpen}
          onClose={() => setIsNewAppointmentModalOpen(false)}
          onSave={handleNewAppointmentSave}
          clients={clients}
        />

        <NewClientModal
          isOpen={isNewClientModalOpen}
          onClose={() => setIsNewClientModalOpen(false)}
          onSave={handleNewClientSave}
        />

        <DayCapacityModal
          isOpen={isDayCapacityModalOpen}
          onClose={() => setIsDayCapacityModalOpen(false)}
          currentCapacity={dayCapacity}
          onSave={handleDayCapacitySave}
        />

        <NotificationsModal
          isOpen={isNotificationsModalOpen}
          onClose={() => setIsNotificationsModalOpen(false)}
        />
      </div>
    </div>
  );
}