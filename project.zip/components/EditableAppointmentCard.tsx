import { useState } from "react";
import { FuturisticCard } from "./FuturisticCard";
import { GlowButton } from "./GlowButton";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { 
  Phone, 
  Clock, 
  DollarSign, 
  Edit2, 
  Trash2, 
  Check, 
  X, 
  MessageCircle,
  CheckCircle,
  XCircle
} from "lucide-react";

interface Client {
  name: string;
  phone: string;
  telegram?: string;
  initials: string;
}

interface Service {
  name: string;
  duration: number;
  price: number;
  icon: "scissors" | "star" | "heart" | "palette";
}

interface EditableAppointmentCardProps {
  client: Client;
  service: Service;
  time: string;
  status: "upcoming" | "completed" | "cancelled";
  onEdit?: (data: any) => void;
  onDelete?: () => void;
  onStatusChange?: (status: "upcoming" | "completed" | "cancelled") => void;
}

export function EditableAppointmentCard({ 
  client, 
  service, 
  time, 
  status,
  onEdit,
  onDelete,
  onStatusChange
}: EditableAppointmentCardProps) {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editData, setEditData] = useState({
    clientName: client.name,
    clientPhone: client.phone,
    clientTelegram: client.telegram || "",
    service: service.name,
    time: time,
    price: service.price
  });

  const statusConfig = {
    upcoming: { 
      color: "text-blue-400", 
      bg: "bg-blue-500/20", 
      border: "border-blue-500/30",
      label: "Запланирована" 
    },
    completed: { 
      color: "text-green-400", 
      bg: "bg-green-500/20", 
      border: "border-green-500/30",
      label: "Завершена" 
    },
    cancelled: { 
      color: "text-red-400", 
      bg: "bg-red-500/20", 
      border: "border-red-500/30",
      label: "Отменена" 
    }
  };

  const currentStatus = statusConfig[status];

  const handleEdit = () => {
    onEdit?.(editData);
    setIsEditModalOpen(false);
  };

  const handleDelete = () => {
    onDelete?.();
    setIsDeleteModalOpen(false);
  };

  const handleInputChange = (field: string, value: any) => {
    setEditData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <>
      <FuturisticCard className="p-4 hover:bg-white/5 transition-all duration-200 cursor-pointer group">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 flex-1">
            <Avatar className="w-10 h-10 border border-white/20">
              <AvatarFallback className="bg-white/10 text-white text-sm">
                {client.initials}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h4 className="text-white text-sm truncate">{client.name}</h4>
                <Badge className={`${currentStatus.bg} ${currentStatus.color} ${currentStatus.border} text-xs px-2 py-0`}>
                  {currentStatus.label}
                </Badge>
              </div>

              {/* Кнопки действий между именем и контактами */}
              <div className="flex items-center gap-1 mb-2 opacity-0 group-hover:opacity-100 transition-opacity">
                {status === "upcoming" && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onStatusChange?.("completed");
                    }}
                    className="p-1.5 rounded-full bg-green-500/20 hover:bg-green-500/30 text-green-400 transition-colors"
                    title="Отметить как выполненную"
                  >
                    <CheckCircle className="w-3 h-3" />
                  </button>
                )}

                {status === "completed" && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onStatusChange?.("upcoming");
                    }}
                    className="p-1.5 rounded-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 transition-colors"
                    title="Вернуть в запланированные"
                  >
                    <CheckCircle className="w-3 h-3" />
                  </button>
                )}

                {status === "cancelled" && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onStatusChange?.("upcoming");
                    }}
                    className="p-1.5 rounded-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 transition-colors"
                    title="Восстановить запись"
                  >
                    <CheckCircle className="w-3 h-3" />
                  </button>
                )}

                {status === "upcoming" && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onStatusChange?.("cancelled");
                    }}
                    className="p-1.5 rounded-full bg-red-500/20 hover:bg-red-500/30 text-red-400 transition-colors"
                    title="Отменить запись"
                  >
                    <XCircle className="w-3 h-3" />
                  </button>
                )}
                
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsEditModalOpen(true);
                  }}
                  className="p-1.5 rounded-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 transition-colors"
                  title="Редактировать"
                >
                  <Edit2 className="w-3 h-3" />
                </button>
                
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsDeleteModalOpen(true);
                  }}
                  className="p-1.5 rounded-full bg-red-500/20 hover:bg-red-500/30 text-red-400 transition-colors"
                  title="Удалить"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
              
              <div className="flex items-center gap-4 text-xs text-white/60">
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{time}</span>
                </div>
                <div className="flex items-center gap-1">
                  <DollarSign className="w-3 h-3" />
                  <span>{service.price}₽</span>
                </div>
              </div>
              
              <p className="text-white/70 text-xs mt-1 truncate">{service.name}</p>
            </div>
          </div>
        </div>

        {/* Контактная информация */}
        {(client.phone || client.telegram) && (
          <div className="flex items-center gap-3 mt-3 pt-3 border-t border-white/10">
            {client.phone && (
              <div className="flex items-center gap-1 text-xs text-white/60">
                <Phone className="w-3 h-3" />
                <span>{client.phone}</span>
              </div>
            )}
            {client.telegram && (
              <div className="flex items-center gap-1 text-xs text-white/60">
                <MessageCircle className="w-3 h-3" />
                <span>{client.telegram}</span>
              </div>
            )}
          </div>
        )}
      </FuturisticCard>

      {/* Модал редактирования */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm mx-auto">
          <DialogHeader>
            <DialogTitle className="text-white">Редактировать запись</DialogTitle>
            <DialogDescription className="text-white/60">
              Измените информацию о записи
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 p-4">
            <div>
              <Label htmlFor="editClientName" className="text-white/80">Имя клиента</Label>
              <Input
                id="editClientName"
                value={editData.clientName}
                onChange={(e) => handleInputChange("clientName", e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40"
              />
            </div>

            <div>
              <Label htmlFor="editClientPhone" className="text-white/80">Телефон</Label>
              <Input
                id="editClientPhone"
                value={editData.clientPhone}
                onChange={(e) => handleInputChange("clientPhone", e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40"
              />
            </div>

            <div>
              <Label htmlFor="editClientTelegram" className="text-white/80">Telegram</Label>
              <Input
                id="editClientTelegram"
                value={editData.clientTelegram}
                onChange={(e) => handleInputChange("clientTelegram", e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40"
              />
            </div>

            <div>
              <Label htmlFor="editService" className="text-white/80">Услуга</Label>
              <Textarea
                id="editService"
                value={editData.service}
                onChange={(e) => handleInputChange("service", e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 resize-none"
                rows={2}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="editTime" className="text-white/80">Время</Label>
                <Input
                  id="editTime"
                  type="time"
                  value={editData.time}
                  onChange={(e) => handleInputChange("time", e.target.value)}
                  className="bg-white/10 border-white/20 text-white focus:border-white/40"
                />
              </div>

              <div>
                <Label htmlFor="editPrice" className="text-white/80">Цена (₽)</Label>
                <Input
                  id="editPrice"
                  type="number"
                  value={editData.price}
                  onChange={(e) => handleInputChange("price", parseInt(e.target.value) || 0)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <GlowButton 
                variant="secondary" 
                className="flex-1" 
                onClick={() => setIsEditModalOpen(false)}
              >
                Отмена
              </GlowButton>
              <GlowButton 
                variant="primary" 
                className="flex-1" 
                onClick={handleEdit}
              >
                Сохранить
              </GlowButton>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Модал подтверждения удаления */}
      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm mx-auto">
          <DialogHeader>
            <DialogTitle className="text-white">Удалить запись?</DialogTitle>
            <DialogDescription className="text-white/60">
              Вы уверены, что хотите удалить эту запись? Это действие нельзя отменить.
            </DialogDescription>
          </DialogHeader>

          <div className="flex gap-3 p-4">
            <GlowButton 
              variant="secondary" 
              className="flex-1" 
              onClick={() => setIsDeleteModalOpen(false)}
            >
              Отмена
            </GlowButton>
            <GlowButton 
              variant="primary" 
              className="flex-1 bg-red-500/20 hover:bg-red-500/30 border-red-500/30 text-red-400"
              onClick={handleDelete}
            >
              Удалить
            </GlowButton>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}