import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { FuturisticCard } from "./FuturisticCard";
import { GlowButton } from "./GlowButton";
import { Bell, CheckCircle } from "lucide-react";

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function NotificationsModal({ isOpen, onClose }: NotificationsModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm mx-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white text-center">
            <Bell className="w-5 h-5 text-blue-400" />
            Уведомления
          </DialogTitle>
        </DialogHeader>

        <div className="p-4">
          <FuturisticCard className="p-8 text-center">
            <div className="flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-green-400" />
              </div>
              
              <div>
                <h3 className="text-white text-lg mb-2">Уведомлений нет</h3>
                <p className="text-white/60 text-sm">
                  Все уведомления прочитаны. Новые уведомления будут появляться здесь.
                </p>
              </div>
            </div>
          </FuturisticCard>

          <div className="mt-6">
            <GlowButton 
              variant="secondary" 
              className="w-full"
              onClick={onClose}
            >
              Закрыть
            </GlowButton>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}