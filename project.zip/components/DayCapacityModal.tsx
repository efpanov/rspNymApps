import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { GlowButton } from "./GlowButton";
import { Users, Target } from "lucide-react";

interface DayCapacityModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCapacity: number;
  onSave: (capacity: number) => void;
}

export function DayCapacityModal({ isOpen, onClose, currentCapacity, onSave }: DayCapacityModalProps) {
  const [capacity, setCapacity] = useState(currentCapacity);

  const handleSave = () => {
    onSave(capacity);
    onClose();
  };

  const handleCancel = () => {
    setCapacity(currentCapacity);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm mx-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <Target className="w-5 h-5 text-blue-400" />
            Настройка загруженности
          </DialogTitle>
          <DialogDescription className="text-white/60">
            Установите максимальное количество клиентов в день для расчета загруженности
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 p-4">
          <div className="space-y-3">
            <Label htmlFor="capacity" className="text-white/80 flex items-center gap-2">
              <Users className="w-4 h-4 text-green-400" />
              Максимальное количество клиентов в день
            </Label>
            <Input
              id="capacity"
              type="number"
              value={capacity}
              onChange={(e) => setCapacity(parseInt(e.target.value) || 0)}
              className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40"
              placeholder="Введите количество"
              min="1"
              max="50"
            />
          </div>

          <div className="bg-white/5 p-4 rounded-lg">
            <h4 className="text-white/90 text-sm mb-2">Текущая загруженность:</h4>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-white/20 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min((2 / Math.max(capacity, 1)) * 100, 100)}%` }}
                ></div>
              </div>
              <span className="text-white/80 text-sm">
                {Math.round((2 / Math.max(capacity, 1)) * 100)}%
              </span>
            </div>
            <p className="text-white/60 text-xs mt-2">
              Сегодня у вас 2 записи из {capacity} возможных
            </p>
          </div>

          <div className="flex gap-3">
            <GlowButton 
              variant="secondary" 
              className="flex-1" 
              onClick={handleCancel}
            >
              Отмена
            </GlowButton>
            <GlowButton 
              variant="primary" 
              className="flex-1" 
              onClick={handleSave}
            >
              Сохранить
            </GlowButton>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}