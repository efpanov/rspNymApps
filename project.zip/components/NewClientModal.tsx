import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { GlowButton } from "./GlowButton";
import { FuturisticCard } from "./FuturisticCard";
import { User, Phone, MessageCircle, Target, DollarSign } from "lucide-react";

interface NewClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (client: ClientData) => void;
}

interface ClientData {
  name: string;
  phone?: string;
  telegram?: string;
  service: string;
  price: number;
}

export function NewClientModal({ isOpen, onClose, onSave }: NewClientModalProps) {
  const [formData, setFormData] = useState<ClientData>({
    name: "",
    phone: "",
    telegram: "",
    service: "",
    price: 0
  });

  const handleInputChange = (field: keyof ClientData, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = () => {
    if (formData.name && formData.service) {
      onSave(formData);
      setFormData({
        name: "",
        phone: "",
        telegram: "",
        service: "",
        price: 0
      });
      onClose();
    }
  };

  const isFormValid = formData.name && formData.service;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm mx-auto max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white text-center text-xl">Новый клиент</DialogTitle>
          <DialogDescription className="text-white/60 text-center">
            Создать шаблон клиента для быстрого добавления записей
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 p-4">
          {/* Информация о клиенте */}
          <FuturisticCard className="p-6">
            <div className="space-y-6">
              <div className="flex items-center gap-2 mb-4">
                <User className="w-5 h-5 text-blue-400" />
                <span className="text-white/90">Информация о клиенте</span>
              </div>
              
              <div className="space-y-5">
                <div>
                  <Label htmlFor="clientName" className="text-white/80 mb-2 block">Имя клиента *</Label>
                  <Input
                    id="clientName"
                    value={formData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 mt-2"
                    placeholder="Введите имя клиента"
                  />
                </div>
                
                <div>
                  <Label htmlFor="clientPhone" className="text-white/80 mb-2 block">Телефон</Label>
                  <Input
                    id="clientPhone"
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 mt-2"
                    placeholder="+7 (999) 123-45-67"
                  />
                </div>

                <div>
                  <Label htmlFor="clientTelegram" className="text-white/80 mb-2 block">Telegram</Label>
                  <Input
                    id="clientTelegram"
                    value={formData.telegram}
                    onChange={(e) => handleInputChange("telegram", e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 mt-2"
                    placeholder="@username или ссылка"
                  />
                </div>
              </div>
            </div>
          </FuturisticCard>

          {/* Услуга по умолчанию */}
          <FuturisticCard className="p-6">
            <div className="space-y-6">
              <div className="flex items-center gap-2 mb-4">
                <Target className="w-5 h-5 text-green-400" />
                <span className="text-white/90">Услуга по умолчанию</span>
              </div>
              
              <div className="space-y-5">
                <div>
                  <Label htmlFor="service" className="text-white/80 mb-2 block">Описание услуги *</Label>
                  <Textarea
                    id="service"
                    value={formData.service}
                    onChange={(e) => handleInputChange("service", e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 resize-none mt-2"
                    placeholder="Стрижка, урок математики, маникюр..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="price" className="text-white/80 mb-2 block">Цена по умолчанию (₽)</Label>
                  <Input
                    id="price"
                    type="number"
                    value={formData.price || ""}
                    onChange={(e) => handleInputChange("price", parseInt(e.target.value) || 0)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 mt-2"
                    placeholder="0"
                    min="0"
                  />
                </div>
              </div>
            </div>
          </FuturisticCard>

          {/* Кнопки действий */}
          <div className="flex gap-3 pt-4">
            <GlowButton 
              variant="secondary" 
              className="flex-1" 
              onClick={onClose}
            >
              Отмена
            </GlowButton>
            <GlowButton 
              variant="primary" 
              className="flex-1" 
              onClick={handleSave}
            >
              {isFormValid ? "Создать клиента" : "Заполните поля"}
            </GlowButton>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}