import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { GlowButton } from "./GlowButton";
import { AlertTriangle } from "lucide-react";

interface DeleteConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
}

export function DeleteConfirmModal({ 
  isOpen, 
  onClose, 
  onConfirm, 
  title, 
  description 
}: DeleteConfirmModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm mx-auto">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-red-400" />
            </div>
            <DialogTitle className="text-white text-lg">{title}</DialogTitle>
          </div>
          <DialogDescription className="text-white/70 text-left">
            {description}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex gap-3 pt-4">
          <GlowButton 
            variant="secondary" 
            className="flex-1" 
            onClick={onClose}
          >
            Отмена
          </GlowButton>
          <GlowButton 
            variant="primary" 
            className="flex-1 bg-red-500/20 hover:bg-red-500/30 text-red-400 border-red-500/40" 
            onClick={onConfirm}
          >
            Удалить
          </GlowButton>
        </div>
      </DialogContent>
    </Dialog>
  );
}