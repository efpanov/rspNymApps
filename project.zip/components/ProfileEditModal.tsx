import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { GlowButton } from "./GlowButton";
import { FuturisticCard } from "./FuturisticCard";
import { User, Briefcase } from "lucide-react";

interface ProfileEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentName: string;
  currentRole: string;
  onSave: (name: string, role: string) => void;
}

export function ProfileEditModal({ isOpen, onClose, currentName, currentRole, onSave }: ProfileEditModalProps) {
  const [name, setName] = useState(currentName);
  const [role, setRole] = useState(currentRole);

  const handleSave = () => {
    onSave(name, role);
    onClose();
  };

  const roles = [
    { value: "hairdresser", label: "Парикмахер" },
    { value: "tutor", label: "Репетитор" },
    { value: "masseur", label: "Массажист" },
    { value: "beautician", label: "Косметолог" },
    { value: "manicurist", label: "Мастер маникюра" },
    { value: "trainer", label: "Тренер" },
    { value: "psychologist", label: "Психолог" },
    { value: "photographer", label: "Фотограф" }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm mx-auto">
        <DialogHeader>
          <DialogTitle className="text-white text-center text-xl">Редактирование профиля</DialogTitle>
          <DialogDescription className="text-white/60 text-center">
            Изменить имя и специализацию мастера
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 p-4">
          <FuturisticCard className="p-4">
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-3">
                <User className="w-5 h-5 text-blue-400" />
                <span className="text-white/90">Персональные данные</span>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="name" className="text-white/80">Имя</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40"
                  placeholder="Введите ваше имя"
                />
              </div>
            </div>
          </FuturisticCard>

          <FuturisticCard className="p-4">
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-3">
                <Briefcase className="w-5 h-5 text-green-400" />
                <span className="text-white/90">Профессия</span>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="role" className="text-white/80">Специализация</Label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white focus:border-white/40">
                    <SelectValue placeholder="Выберите профессию" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-gray-700">
                    {roles.map((roleOption) => (
                      <SelectItem 
                        key={roleOption.value} 
                        value={roleOption.value}
                        className="text-white hover:bg-white/10"
                      >
                        {roleOption.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </FuturisticCard>

          <div className="flex gap-3 pt-4">
            <GlowButton 
              variant="secondary" 
              className="flex-1" 
              onClick={onClose}
            >
              Отмена
            </GlowButton>
            <GlowButton 
              variant="primary" 
              className="flex-1" 
              onClick={handleSave}
            >
              Сохранить
            </GlowButton>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}