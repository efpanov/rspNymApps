import { useState } from "react";
import { FuturisticCard } from "./FuturisticCard";
import { GlowButton } from "./GlowButton";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Building, Edit2, Palette } from "lucide-react";

interface OrganizationSettingsProps {
  organizationName: string;
  organizationIcon: string;
  onSave: (name: string, icon: string) => void;
}

export function OrganizationSettings({ organizationName, organizationIcon, onSave }: OrganizationSettingsProps) {
  const [editMode, setEditMode] = useState(false);
  const [name, setName] = useState(organizationName);
  const [icon, setIcon] = useState(organizationIcon);

  const organizationIcons = [
    { value: "scissors", label: "Ножницы", icon: "✂️" },
    { value: "palette", label: "Палитра", icon: "🎨" },
    { value: "sparkles", label: "Блеск", icon: "✨" },
    { value: "heart", label: "Сердце", icon: "💖" },
    { value: "crown", label: "Корона", icon: "👑" },
    { value: "diamond", label: "Бриллиант", icon: "💎" },
    { value: "flower", label: "Цветок", icon: "🌸" },
    { value: "star", label: "Звезда", icon: "⭐" },
    { value: "beauty", label: "Красота", icon: "💄" },
    { value: "spa", label: "СПА", icon: "🧖‍♀️" },
    { value: "nail", label: "Маникюр", icon: "💅" },
    { value: "book", label: "Книга", icon: "📚" },
    { value: "music", label: "Музыка", icon: "🎵" },
    { value: "camera", label: "Камера", icon: "📸" },
    { value: "gym", label: "Спорт", icon: "💪" },
    { value: "brain", label: "Психология", icon: "🧠" }
  ];

  const handleSave = () => {
    onSave(name, icon);
    setEditMode(false);
  };

  const handleCancel = () => {
    setName(organizationName);
    setIcon(organizationIcon);
    setEditMode(false);
  };

  const selectedIconData = organizationIcons.find(i => i.value === icon);

  return (
    <FuturisticCard className="p-6">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Building className="w-5 h-5 text-blue-400" />
            <h3 className="text-white text-lg">Организация</h3>
          </div>
          {!editMode && (
            <GlowButton
              variant="secondary"
              className="p-2"
              onClick={() => setEditMode(true)}
            >
              <Edit2 className="w-4 h-4" />
            </GlowButton>
          )}
        </div>

        {editMode ? (
          <div className="space-y-6">
            <div className="space-y-3">
              <Label htmlFor="orgName" className="text-white/80">Название организации</Label>
              <Input
                id="orgName"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40"
                placeholder="Введите название"
              />
            </div>

            <div className="space-y-3">
              <Label htmlFor="orgIcon" className="text-white/80">Иконка организации</Label>
              <Select value={icon} onValueChange={setIcon}>
                <SelectTrigger className="bg-white/10 border-white/20 text-white focus:border-white/40">
                  <SelectValue placeholder="Выберите иконку" />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-gray-700 max-h-60">
                  {organizationIcons.map((iconOption) => (
                    <SelectItem 
                      key={iconOption.value} 
                      value={iconOption.value}
                      className="text-white hover:bg-white/10"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-lg">{iconOption.icon}</span>
                        <span>{iconOption.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-3">
              <GlowButton 
                variant="secondary" 
                className="flex-1" 
                onClick={handleCancel}
              >
                Отмена
              </GlowButton>
              <GlowButton 
                variant="primary" 
                className="flex-1" 
                onClick={handleSave}
              >
                Сохранить
              </GlowButton>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-4 p-4 bg-white/5 rounded-lg">
              <div className="text-3xl">
                {selectedIconData?.icon || "✂️"}
              </div>
              <div>
                <h4 className="text-white text-lg">{organizationName}</h4>
                <p className="text-white/60 text-sm">
                  {selectedIconData?.label || "Иконка"}
                </p>
              </div>
            </div>
            
            <div className="text-white/60 text-sm">
              Нажмите кнопку редактирования для изменения названия и иконки вашей организации
            </div>
          </div>
        )}
      </div>
    </FuturisticCard>
  );
}