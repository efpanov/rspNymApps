import { Card } from "./ui/card";
import { cn } from "./ui/utils";

interface FuturisticCardProps {
  children: React.ReactNode;
  className?: string;
  glow?: boolean;
}

export function FuturisticCard({ children, className, glow = false }: FuturisticCardProps) {
  return (
    <Card 
      className={cn(
        "bg-gray-900/50 border-gray-700/50 backdrop-blur-sm transition-all duration-300",
        glow && "shadow-[0_0_15px_rgba(255,255,255,0.1)] hover:shadow-[0_0_25px_rgba(255,255,255,0.2)]",
        className
      )}
    >
      {children}
    </Card>
  );
}