import { useState } from "react";
import { FuturisticCard } from "./FuturisticCard";
import { GlowButton } from "./GlowButton";
import { OrganizationSettings } from "./OrganizationSettings";
import { ProfileEditModal } from "./ProfileEditModal";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Crown, CreditCard, Check, Zap, Shield, Calendar, Star, User, Building, MessageSquare, HelpCircle } from "lucide-react";

interface SubscriptionSettingsProps {
  isPaymentModalOpen: boolean;
  setIsPaymentModalOpen: (open: boolean) => void;
  organizationName: string;
  organizationIcon: string;
  masterName: string;
  masterRole: string;
  onOrganizationSave: (name: string, icon: string) => void;
  onProfileSave: (name: string, role: string) => void;
}

export function SubscriptionSettings({ 
  isPaymentModalOpen, 
  setIsPaymentModalOpen,
  organizationName,
  organizationIcon,
  masterName,
  masterRole,
  onOrganizationSave,
  onProfileSave
}: SubscriptionSettingsProps) {
  const [selectedPlan, setSelectedPlan] = useState<"month" | "year" | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  const plans = [
    {
      id: "month",
      name: "Месячная подписка",
      price: 299,
      period: "мес",
      savings: null,
      popular: false,
      features: [
        "Неограниченные записи",
        "Календарь и уведомления", 
        "Статистика доходов",
        "Экспорт данных"
      ]
    },
    {
      id: "year",
      name: "Годовая подписка",
      price: 2299,
      originalPrice: 3588,
      period: "год",
      savings: "36%",
      popular: true,
      features: [
        "Все функции месячной подписки",
        "Приоритетная поддержка",
        "Расширенная аналитика",
        "Резервное копирование",
        "Множественные профили"
      ]
    }
  ];

  const handlePayment = () => {
    // Здесь будет логика оплаты
    alert(`Оплата ${selectedPlan === "month" ? "месячной" : "годовой"} подписки`);
    setIsPaymentModalOpen(false);
    setSelectedPlan(null);
  };

  return (
    <>
      <div className="space-y-6">
        {/* Настройки организации */}
        <OrganizationSettings
          organizationName={organizationName}
          organizationIcon={organizationIcon}
          onSave={onOrganizationSave}
        />

        {/* Настройки профиля */}
        <FuturisticCard className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-green-400" />
              <h3 className="text-white text-lg">Профиль мастера</h3>
            </div>
            <GlowButton
              variant="secondary"
              className="p-2"
              onClick={() => setIsProfileModalOpen(true)}
            >
              <Star className="w-4 h-4" />
            </GlowButton>
          </div>
          
          <div className="mt-4 p-4 bg-white/5 rounded-lg">
            <h4 className="text-white">{masterName}</h4>
            <p className="text-white/60 text-sm">
              {masterRole === "hairdresser" ? "Парикмахер" : 
               masterRole === "tutor" ? "Репетитор" :
               masterRole === "masseur" ? "Массажист" :
               masterRole === "beautician" ? "Косметолог" :
               masterRole === "manicurist" ? "Мастер маникюра" :
               masterRole === "trainer" ? "Тренер" :
               masterRole === "psychologist" ? "Психолог" :
               masterRole === "photographer" ? "Фотограф" : "Специалист"}
            </p>
          </div>
        </FuturisticCard>
        {/* Текущий статус */}
        <FuturisticCard glow className="p-6 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/10 to-transparent"></div>
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-4">
              <Crown className="w-6 h-6 text-yellow-400" />
              <div>
                <h3 className="text-white text-lg">Премиум статус</h3>
                <p className="text-white/60 text-sm">Активен до 19 января 2025</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                АКТИВНА
              </Badge>
              <span className="text-white/60 text-sm">Автопродление включено</span>
            </div>
          </div>
        </FuturisticCard>

        {/* Планы подписки */}
        <div>
          <h3 className="text-xl text-white mb-4">Планы подписки</h3>
          <div className="space-y-4">
            {plans.map((plan) => (
              <FuturisticCard 
                key={plan.id}
                glow={plan.popular}
                className={`p-6 relative overflow-hidden transition-all duration-300 ${
                  plan.popular ? 'border-yellow-500/40' : ''
                }`}
              >
                {plan.popular && (
                  <>
                    <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/10 to-transparent"></div>
                    <Badge className="absolute top-4 right-4 bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                      ПОПУЛЯРНЫЙ
                    </Badge>
                  </>
                )}
                
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="text-white text-lg">{plan.name}</h4>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl text-white">{plan.price}₽</span>
                        <span className="text-white/60">/{plan.period}</span>
                        {plan.originalPrice && (
                          <span className="text-white/40 line-through text-sm">
                            {plan.originalPrice}₽
                          </span>
                        )}
                      </div>
                      {plan.savings && (
                        <div className="text-green-400 text-sm">
                          Экономия {plan.savings}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2 mb-6">
                    {plan.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-400" />
                        <span className="text-white/80 text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <GlowButton
                    variant={plan.popular ? "primary" : "secondary"}
                    className="w-full"
                    onClick={() => {
                      setSelectedPlan(plan.id as "month" | "year");
                      setIsPaymentModalOpen(true);
                    }}
                  >
                    {plan.popular ? "Выбрать план" : "Перейти на план"}
                  </GlowButton>
                </div>
              </FuturisticCard>
            ))}
          </div>
        </div>

        {/* Преимущества подписки */}
        <FuturisticCard className="p-6">
          <h4 className="text-white text-lg mb-4">Преимущества подписки</h4>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: Zap, label: "Быстрая работа", color: "text-yellow-400" },
              { icon: Shield, label: "Защита данных", color: "text-green-400" },
              { icon: Calendar, label: "Умный календарь", color: "text-blue-400" },
              { icon: Star, label: "Премиум поддержка", color: "text-purple-400" }
            ].map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                <item.icon className={`w-5 h-5 ${item.color}`} />
                <span className="text-white/80 text-sm">{item.label}</span>
              </div>
            ))}
          </div>
        </FuturisticCard>

        {/* Техническая поддержка */}
        <FuturisticCard className="p-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <HelpCircle className="w-5 h-5 text-yellow-400" />
              <h3 className="text-white text-lg">Поддержка</h3>
            </div>
            
            <p className="text-white/60 text-sm">
              Нужна помощь? Наша команда поддержки готова помочь вам с любыми вопросами
            </p>
            
            <GlowButton 
              variant="secondary" 
              className="w-full"
              onClick={() => window.open('https://t.me/nymceo', '_blank')}
            >
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                <span>Связаться с поддержкой</span>
              </div>
            </GlowButton>
          </div>
        </FuturisticCard>

        {/* Дополнительное пространство снизу */}
        <div className="pb-20"></div>
      </div>

      {/* Модал оплаты */}
      <Dialog open={isPaymentModalOpen} onOpenChange={setIsPaymentModalOpen}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm mx-auto">
          <DialogHeader>
            <DialogTitle className="text-white text-center text-xl">Оплата подписки</DialogTitle>
            <DialogDescription className="text-white/60 text-center">
              Выберите способ оплаты и подтвердите покупку подписки
            </DialogDescription>
          </DialogHeader>
          
          {selectedPlan && (
            <div className="space-y-6 p-4">
              <FuturisticCard className="p-4">
                <div className="text-center">
                  <h4 className="text-white text-lg mb-2">
                    {selectedPlan === "month" ? "Месячная подписка" : "Годовая подписка"}
                  </h4>
                  <div className="text-3xl text-white mb-1">
                    {selectedPlan === "month" ? "299" : "2299"}₽
                  </div>
                  <p className="text-white/60 text-sm">
                    {selectedPlan === "month" ? "за месяц" : "за год (экономия 36%)"}
                  </p>
                </div>
              </FuturisticCard>

              <FuturisticCard className="p-4">
                <div className="flex items-center gap-3 mb-4">
                  <CreditCard className="w-5 h-5 text-blue-400" />
                  <span className="text-white/90">Способ оплаты</span>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-white/10 rounded-lg">
                    <div className="w-8 h-6 bg-gradient-to-r from-blue-500 to-purple-500 rounded"></div>
                    <span className="text-white text-sm">Банковская карта</span>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg opacity-60">
                    <div className="w-8 h-6 bg-gradient-to-r from-green-500 to-blue-500 rounded"></div>
                    <span className="text-white/60 text-sm">СБП (скоро)</span>
                  </div>
                </div>
              </FuturisticCard>

              <div className="flex gap-3 pt-4">
                <GlowButton 
                  variant="secondary" 
                  className="flex-1" 
                  onClick={() => setIsPaymentModalOpen(false)}
                >
                  Отмена
                </GlowButton>
                <GlowButton 
                  variant="primary" 
                  className="flex-1" 
                  onClick={handlePayment}
                >
                  Оплатить
                </GlowButton>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Модал редактирования профиля */}
      <ProfileEditModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentName={masterName}
        currentRole={masterRole}
        onSave={onProfileSave}
      />
    </>
  );
}