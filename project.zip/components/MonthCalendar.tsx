import { useState } from "react";
import { FuturisticCard } from "./FuturisticCard";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface AppointmentData {
  id: string;
  time: string;
  client: string;
  service: string;
  price: number;
}

interface CalendarDay {
  date: number;
  isCurrentMonth: boolean;
  isToday: boolean;
  appointments: AppointmentData[];
}

export function MonthCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  
  // Мок-данные записей на месяц
  const appointmentsData: { [key: string]: AppointmentData[] } = {
    "2024-12-19": [
      { id: "1", time: "11:00", client: "Елена П.", service: "Маникюр", price: 1500 },
      { id: "2", time: "17:00", client: "Игорь Д.", service: "Стрижка", price: 2000 }
    ],
    "2024-12-20": [
      { id: "3", time: "12:00", client: "Ольга Н.", service: "Укладка", price: 2500 }
    ],
    "2024-12-21": [
      { id: "4", time: "09:00", client: "Петр М.", service: "Стрижка", price: 2000 },
      { id: "5", time: "15:00", client: "Анна К.", service: "Окрашивание", price: 4500 }
    ],
    "2024-12-23": [
      { id: "6", time: "11:00", client: "Мария Л.", service: "Маникюр", price: 1500 }
    ],
    "2024-12-24": [
      { id: "7", time: "14:00", client: "София В.", service: "Стрижка", price: 2000 }
    ]
  };

  const months = [
    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
  ];

  const daysOfWeek = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

  const getDaysInMonth = (date: Date): CalendarDay[] => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startDayOfWeek = (firstDay.getDay() + 6) % 7; // Понедельник = 0

    const days: CalendarDay[] = [];
    const today = new Date();

    // Добавляем дни предыдущего месяца
    const prevMonth = new Date(year, month - 1, 0);
    for (let i = startDayOfWeek - 1; i >= 0; i--) {
      const date = prevMonth.getDate() - i;
      days.push({
        date,
        isCurrentMonth: false,
        isToday: false,
        appointments: []
      });
    }

    // Добавляем дни текущего месяца
    for (let date = 1; date <= daysInMonth; date++) {
      const dateString = `${year}-${String(month + 1).padStart(2, '0')}-${String(date).padStart(2, '0')}`;
      const isToday = today.getFullYear() === year && 
                     today.getMonth() === month && 
                     today.getDate() === date;
      
      days.push({
        date,
        isCurrentMonth: true,
        isToday,
        appointments: appointmentsData[dateString] || []
      });
    }

    // Добавляем дни следующего месяца до заполнения сетки
    const remainingCells = 42 - days.length;
    for (let date = 1; date <= remainingCells; date++) {
      days.push({
        date,
        isCurrentMonth: false,
        isToday: false,
        appointments: []
      });
    }

    return days;
  };

  const days = getDaysInMonth(currentDate);

  const goToPrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const goToNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  return (
    <div className="space-y-4">
      {/* Заголовок календаря */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl text-white">
            {months[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h2>
          <p className="text-white/60 text-sm">Календарь записей</p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={goToPrevMonth}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
          >
            <ChevronLeft className="w-4 h-4 text-white" />
          </button>
          <button 
            onClick={goToNextMonth}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
          >
            <ChevronRight className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>

      <FuturisticCard className="p-4">
        {/* Заголовки дней недели */}
        <div className="grid grid-cols-7 gap-1 mb-2">
          {daysOfWeek.map((day) => (
            <div key={day} className="text-center text-white/60 text-sm py-2">
              {day}
            </div>
          ))}
        </div>

        {/* Сетка календаря */}
        <div className="grid grid-cols-7 gap-1">
          {days.map((day, index) => (
            <div
              key={index}
              className={`
                min-h-[60px] p-1 rounded-lg border border-transparent transition-colors
                ${day.isCurrentMonth ? 'hover:bg-white/5' : ''}
                ${day.isToday ? 'bg-white/10 border-white/20 shadow-[0_0_10px_rgba(255,255,255,0.2)]' : ''}
              `}
            >
              <div className={`
                text-sm mb-1 
                ${day.isCurrentMonth ? (day.isToday ? 'text-white' : 'text-white/80') : 'text-white/30'}
              `}>
                {day.date}
              </div>
              
              {day.appointments.length > 0 && (
                <div className="space-y-1">
                  {day.appointments.slice(0, 2).map((appointment) => (
                    <div
                      key={appointment.id}
                      className="bg-blue-500/20 text-blue-300 text-xs p-1 rounded truncate"
                      title={`${appointment.time} - ${appointment.client}`}
                    >
                      {appointment.time}
                    </div>
                  ))}
                  {day.appointments.length > 2 && (
                    <div className="text-white/50 text-xs">
                      +{day.appointments.length - 2}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </FuturisticCard>

      {/* Легенда */}
      <div className="flex items-center gap-4 text-sm text-white/60">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-blue-500/20 rounded"></div>
          <span>Записи</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-white/10 border border-white/20 rounded"></div>
          <span>Сегодня</span>
        </div>
      </div>
    </div>
  );
}