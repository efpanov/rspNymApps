import { useState } from "react";
import { FuturisticCard } from "./FuturisticCard";
import { GlowButton } from "./GlowButton";
import { ChevronLeft, ChevronRight, Calendar, X } from "lucide-react";

interface FullMonthCalendarProps {
  isOpen: boolean;
  onClose: () => void;
  onDateSelect?: (date: Date) => void;
}

export function FullMonthCalendar({ isOpen, onClose, onDateSelect }: FullMonthCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());

  if (!isOpen) return null;

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  
  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const firstDayWeekday = firstDayOfMonth.getDay() === 0 ? 7 : firstDayOfMonth.getDay(); // Понедельник = 1
  const daysInMonth = lastDayOfMonth.getDate();

  const monthNames = [
    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
  ];

  const weekdays = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

  const goToPrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const goToNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const handleDateClick = (day: number) => {
    const selectedDate = new Date(year, month, day);
    onDateSelect?.(selectedDate);
  };

  const renderCalendarDays = () => {
    const days = [];
    
    // Пустые ячейки для дней предыдущего месяца
    for (let i = 1; i < firstDayWeekday; i++) {
      days.push(
        <div key={`empty-${i}`} className="p-3"></div>
      );
    }

    // Дни текущего месяца
    for (let day = 1; day <= daysInMonth; day++) {
      const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();
      const hasAppointment = day === 19 || day === 21; // Мок данные

      days.push(
        <button
          key={day}
          onClick={() => handleDateClick(day)}
          className={`
            p-3 rounded-lg text-center relative transition-all duration-200
            hover:bg-white/10 hover:scale-105
            ${isToday ? 'bg-blue-500/30 border border-blue-400 text-white' : 'text-white/80'}
            ${hasAppointment ? 'after:absolute after:bottom-1 after:left-1/2 after:transform after:-translate-x-1/2 after:w-1 after:h-1 after:bg-green-400 after:rounded-full' : ''}
          `}
        >
          <span className="text-sm">{day}</span>
        </button>
      );
    }

    return days;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-sm mx-auto">
        <FuturisticCard className="p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
          >
            <X className="w-4 h-4 text-white" />
          </button>

          {/* Заголовок календаря */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-400" />
              <h2 className="text-xl text-white">
                {monthNames[month]} {year}
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={goToPrevMonth}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
              >
                <ChevronLeft className="w-4 h-4 text-white" />
              </button>
              <button 
                onClick={goToNextMonth}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
              >
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>

          {/* Заголовки дней недели */}
          <div className="grid grid-cols-7 gap-1 mb-4">
            {weekdays.map((day) => (
              <div key={day} className="text-center text-white/60 text-sm p-2">
                {day}
              </div>
            ))}
          </div>

          {/* Календарная сетка */}
          <div className="grid grid-cols-7 gap-1 mb-6">
            {renderCalendarDays()}
          </div>

          {/* Легенда */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-3 h-3 bg-blue-500/30 border border-blue-400 rounded"></div>
              <span className="text-white/70">Сегодня</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <div className="w-3 h-3 bg-white/10 rounded relative">
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-green-400 rounded-full"></div>
              </div>
              <span className="text-white/70">Есть записи</span>
            </div>
          </div>

          <div className="mt-6">
            <GlowButton 
              variant="secondary" 
              className="w-full"
              onClick={onClose}
            >
              Закрыть
            </GlowButton>
          </div>
        </FuturisticCard>
      </div>
    </div>
  );
}