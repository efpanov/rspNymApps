import { useState } from "react";
import { FuturisticCard } from "./FuturisticCard";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Edit2, Trash2, Phone, MessageCircle } from "lucide-react";
import { EditClientModal } from "./EditClientModal";
import { DeleteConfirmModal } from "./DeleteConfirmModal";

interface ClientData {
  id: number;
  name: string;
  phone?: string;
  telegram?: string;
  service: string;
  price: number;
  initials: string;
}

interface ClientCardProps {
  client: ClientData;
  onEdit: (clientId: number, data: any) => void;
  onDelete: (clientId: number) => void;
  onSelect?: (client: ClientData) => void;
}

export function ClientCard({ client, onEdit, onDelete, onSelect }: ClientCardProps) {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  const handleEdit = (data: any) => {
    onEdit(client.id, data);
    setIsEditModalOpen(false);
  };

  const handleDelete = () => {
    onDelete(client.id);
    setIsDeleteModalOpen(false);
  };

  return (
    <>
      <FuturisticCard 
        className="p-4 group hover:bg-white/5 transition-colors cursor-pointer"
        onClick={() => onSelect?.(client)}
      >
        <div className="flex items-center gap-3">
          <Avatar className="w-12 h-12 border border-white/20">
            <AvatarFallback className="bg-white/10 text-white">
              {client.initials}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h4 className="text-white truncate">{client.name}</h4>
            </div>

            {/* Кнопки действий */}
            <div className="flex items-center gap-1 mb-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsEditModalOpen(true);
                }}
                className="p-1.5 rounded-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 transition-colors"
                title="Редактировать"
              >
                <Edit2 className="w-3 h-3" />
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsDeleteModalOpen(true);
                }}
                className="p-1.5 rounded-full bg-red-500/20 hover:bg-red-500/30 text-red-400 transition-colors"
                title="Удалить"
              >
                <Trash2 className="w-3 h-3" />
              </button>

              {client.phone && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    window.open(`tel:${client.phone}`, '_blank');
                  }}
                  className="p-1.5 rounded-full bg-green-500/20 hover:bg-green-500/30 text-green-400 transition-colors"
                  title="Позвонить"
                >
                  <Phone className="w-3 h-3" />
                </button>
              )}

              {client.telegram && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    window.open(
                      client.telegram.startsWith('@') 
                        ? `https://t.me/${client.telegram.slice(1)}` 
                        : client.telegram, 
                      '_blank'
                    );
                  }}
                  className="p-1.5 rounded-full bg-blue-400/20 hover:bg-blue-400/30 text-blue-300 transition-colors"
                  title="Написать в Telegram"
                >
                  <MessageCircle className="w-3 h-3" />
                </button>
              )}
            </div>
            
            <div className="flex items-center gap-4 text-xs text-white/60 mb-1">
              {client.phone && (
                <div className="flex items-center gap-1">
                  <Phone className="w-3 h-3" />
                  <span>{client.phone}</span>
                </div>
              )}
              {client.telegram && (
                <div className="flex items-center gap-1">
                  <MessageCircle className="w-3 h-3" />
                  <span>{client.telegram}</span>
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <p className="text-white/70 text-sm truncate flex-1">{client.service}</p>
              <Badge variant="secondary" className="bg-white/10 text-white/80 border-white/20 text-xs">
                {client.price}₽
              </Badge>
            </div>
          </div>
        </div>
      </FuturisticCard>

      <EditClientModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        client={client}
        onSave={handleEdit}
      />

      <DeleteConfirmModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleDelete}
        title="Удалить клиента?"
        description={`Вы действительно хотите удалить клиента "${client.name}"? Это действие нельзя отменить.`}
      />
    </>
  );
}