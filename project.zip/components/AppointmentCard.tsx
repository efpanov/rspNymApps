import { FuturisticCard } from "./FuturisticCard";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Clock, Phone, Scissors, Palette, Star } from "lucide-react";

interface AppointmentCardProps {
  client: {
    name: string;
    phone: string;
    avatar?: string;
    initials: string;
  };
  service: {
    name: string;
    duration: number;
    price: number;
    icon: "scissors" | "palette" | "star";
  };
  time: string;
  status: "upcoming" | "completed" | "cancelled";
}

const serviceIcons = {
  scissors: Scissors,
  palette: Palette,
  star: Star
};

const statusColors = {
  upcoming: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  completed: "bg-green-500/20 text-green-400 border-green-500/30",
  cancelled: "bg-red-500/20 text-red-400 border-red-500/30"
};

const statusLabels = {
  upcoming: "Предстоит",
  completed: "Выполнено",
  cancelled: "Отменено"
};

export function AppointmentCard({ client, service, time, status }: AppointmentCardProps) {
  const ServiceIcon = serviceIcons[service.icon];
  
  return (
    <FuturisticCard className="p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <Avatar className="w-10 h-10 border border-white/20">
            <AvatarImage src={client.avatar} alt={client.name} />
            <AvatarFallback className="bg-white/10 text-white">
              {client.initials}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="text-white text-sm">{client.name}</p>
            <div className="flex items-center gap-1 text-white/60 text-xs">
              <Phone className="w-3 h-3" />
              <span>{client.phone}</span>
            </div>
          </div>
        </div>
        <Badge className={`text-xs border ${statusColors[status]}`}>
          {statusLabels[status]}
        </Badge>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ServiceIcon className="w-4 h-4 text-white/70" />
          <span className="text-white/90 text-sm">{service.name}</span>
        </div>
        <div className="text-right">
          <div className="flex items-center gap-1 text-white/60 text-xs mb-1">
            <Clock className="w-3 h-3" />
            <span>{time}</span>
          </div>
          <p className="text-white text-sm">{service.price}₽</p>
        </div>
      </div>
    </FuturisticCard>
  );
}