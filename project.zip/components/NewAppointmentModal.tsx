import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { GlowButton } from "./GlowButton";
import { FuturisticCard } from "./FuturisticCard";
import { User, Phone, Target, Clock, DollarSign, MessageCircle, Calendar, Plus, X, Users } from "lucide-react";

interface ClientTemplate {
  id: number;
  name: string;
  phone?: string;
  telegram?: string;
  service: string;
  price: number;
  initials: string;
}

interface NewAppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (appointment: AppointmentData) => void;
  clients?: ClientTemplate[];
}

interface AppointmentData {
  clientName: string;
  clientPhone: string;
  clientTelegram: string;
  service: string;
  dates: string[];
  time: string;
  price: number;
}

export function NewAppointmentModal({ isOpen, onClose, onSave, clients = [] }: NewAppointmentModalProps) {
  const [formData, setFormData] = useState<AppointmentData>({
    clientName: "",
    clientPhone: "",
    clientTelegram: "",
    service: "",
    dates: [new Date().toISOString().split('T')[0]],
    time: "",
    price: 0
  });

  const [showClientSelect, setShowClientSelect] = useState(false);

  const handleInputChange = (field: keyof AppointmentData, value: string | number | string[]) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addDate = () => {
    setFormData(prev => ({
      ...prev,
      dates: [...prev.dates, ""]
    }));
  };

  const removeDate = (index: number) => {
    if (formData.dates.length > 1) {
      setFormData(prev => ({
        ...prev,
        dates: prev.dates.filter((_, i) => i !== index)
      }));
    }
  };

  const updateDate = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      dates: prev.dates.map((date, i) => i === index ? value : date)
    }));
  };

  const selectClient = (client: ClientTemplate) => {
    setFormData(prev => ({
      ...prev,
      clientName: client.name,
      clientPhone: client.phone || "",
      clientTelegram: client.telegram || "",
      service: client.service,
      price: client.price
    }));
    setShowClientSelect(false);
  };

  const handleSave = () => {
    if (formData.clientName && formData.service && formData.dates.every(date => date) && formData.time) {
      onSave(formData);
      setFormData({
        clientName: "",
        clientPhone: "",
        clientTelegram: "",
        service: "",
        dates: [new Date().toISOString().split('T')[0]],
        time: "",
        price: 0
      });
      onClose();
    }
  };

  const isFormValid = formData.clientName && formData.service && formData.dates.every(date => date) && formData.time;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-sm mx-auto max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white text-center text-xl">Новая запись</DialogTitle>
          <DialogDescription className="text-white/60 text-center">
            Создать новую запись клиента с указанием времени и услуги
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 p-4">
          {/* Информация о клиенте */}
          <FuturisticCard className="p-6">
            <div className="space-y-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5 text-blue-400" />
                  <span className="text-white/90">Клиент</span>
                </div>
                {clients.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowClientSelect(!showClientSelect)}
                    className="flex items-center gap-1 px-3 py-1 rounded-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 text-sm transition-colors"
                  >
                    <Users className="w-3 h-3" />
                    Выбрать
                  </button>
                )}
              </div>

              {/* Выбор из существующих клиентов */}
              {showClientSelect && clients.length > 0 && (
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  <Label className="text-white/80 text-sm">Выберите клиента:</Label>
                  {clients.map((client) => (
                    <div
                      key={client.id}
                      onClick={() => selectClient(client)}
                      className="p-3 rounded bg-white/5 hover:bg-white/10 cursor-pointer transition-colors border border-white/10"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-white text-sm">{client.name}</span>
                        <span className="text-white/60 text-xs">• {client.service}</span>
                        <span className="text-white/60 text-xs">• {client.price}₽</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              <div className="space-y-5">
                <div>
                  <Label htmlFor="clientName" className="text-white/80 mb-2 block">Имя клиента *</Label>
                  <Input
                    id="clientName"
                    value={formData.clientName}
                    onChange={(e) => handleInputChange("clientName", e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 mt-2"
                    placeholder="Введите имя клиента"
                  />
                </div>
                
                <div>
                  <Label htmlFor="clientPhone" className="text-white/80 mb-2 block">Телефон</Label>
                  <Input
                    id="clientPhone"
                    value={formData.clientPhone}
                    onChange={(e) => handleInputChange("clientPhone", e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 mt-2"
                    placeholder="+7 (999) 123-45-67"
                  />
                </div>

                <div>
                  <Label htmlFor="clientTelegram" className="text-white/80 mb-2 block">Telegram</Label>
                  <Input
                    id="clientTelegram"
                    value={formData.clientTelegram}
                    onChange={(e) => handleInputChange("clientTelegram", e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 mt-2"
                    placeholder="@username или ссылка"
                  />
                </div>
              </div>
            </div>
          </FuturisticCard>

          {/* Детали услуги */}
          <FuturisticCard className="p-6">
            <div className="space-y-6">
              <div className="flex items-center gap-2 mb-4">
                <Target className="w-5 h-5 text-green-400" />
                <span className="text-white/90">Услуга</span>
              </div>
              
              <div>
                <Label htmlFor="service" className="text-white/80 mb-2 block">Цель записи *</Label>
                <Textarea
                  id="service"
                  value={formData.service}
                  onChange={(e) => handleInputChange("service", e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 resize-none mt-2"
                  placeholder="Стрижка, урок математики, маникюр..."
                  rows={3}
                />
              </div>
            </div>
          </FuturisticCard>

          {/* Время и дата */}
          <FuturisticCard className="p-6">
            <div className="space-y-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-purple-400" />
                  <span className="text-white/90">Даты и время</span>
                </div>
                <button
                  type="button"
                  onClick={addDate}
                  className="p-2 rounded-full bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 transition-colors"
                  title="Добавить дату"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              
              <div className="space-y-4">
                {formData.dates.map((date, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="flex-1">
                      <Label className="text-white/80 mb-2 block">
                        Дата {index + 1} *
                      </Label>
                      <Input
                        type="date"
                        value={date}
                        onChange={(e) => updateDate(index, e.target.value)}
                        className="bg-white/10 border-white/20 text-white focus:border-white/40 mt-2"
                      />
                    </div>
                    {formData.dates.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeDate(index)}
                        className="mt-6 p-2 rounded-full bg-red-500/20 hover:bg-red-500/30 text-red-400 transition-colors"
                        title="Удалить дату"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
                
                <div>
                  <Label htmlFor="time" className="text-white/80 mb-2 block">Время *</Label>
                  <Input
                    id="time"
                    type="time"
                    value={formData.time}
                    onChange={(e) => handleInputChange("time", e.target.value)}
                    className="bg-white/10 border-white/20 text-white focus:border-white/40 mt-2"
                  />
                </div>
              </div>
            </div>
          </FuturisticCard>

          {/* Стоимость */}
          <FuturisticCard className="p-6">
            <div className="space-y-6">
              <div className="flex items-center gap-2 mb-4">
                <DollarSign className="w-5 h-5 text-yellow-400" />
                <span className="text-white/90">Стоимость</span>
              </div>
              
              <div>
                <Label htmlFor="price" className="text-white/80 mb-2 block">Цена (₽)</Label>
                <Input
                  id="price"
                  type="number"
                  value={formData.price || ""}
                  onChange={(e) => handleInputChange("price", parseInt(e.target.value) || 0)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white/40 mt-2"
                  placeholder="0"
                  min="0"
                />
              </div>
            </div>
          </FuturisticCard>

          {/* Кнопки действий */}
          <div className="flex gap-3 pt-4">
            <GlowButton 
              variant="secondary" 
              className="flex-1" 
              onClick={onClose}
            >
              Отмена
            </GlowButton>
            <GlowButton 
              variant="primary" 
              className="flex-1" 
              onClick={handleSave}
            >
              {isFormValid ? "Создать запись" : "Заполните поля"}
            </GlowButton>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}