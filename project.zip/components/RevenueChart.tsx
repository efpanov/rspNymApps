import { FuturisticCard } from "./FuturisticCard";
import { TrendingUp, TrendingDown, DollarSign, Calendar } from "lucide-react";

interface RevenueData {
  period: string;
  amount: number;
  change: number;
  appointments: number;
}

interface RevenueChartProps {
  monthData: RevenueData;
  yearData: RevenueData;
}

export function RevenueChart({ monthData, yearData }: RevenueChartProps) {
  return (
    <div className="space-y-4">
      {/* Месячная статистика */}
      <FuturisticCard glow className="p-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-400" />
              <h3 className="text-white">Доход за месяц</h3>
            </div>
            <div className={`flex items-center gap-1 text-sm ${
              monthData.change >= 0 ? 'text-green-400' : 'text-red-400'
            }`}>
              {monthData.change >= 0 ? 
                <TrendingUp className="w-4 h-4" /> : 
                <TrendingDown className="w-4 h-4" />
              }
              <span>{Math.abs(monthData.change)}%</span>
            </div>
          </div>
          
          <div className="mb-4">
            <p className="text-2xl text-white mb-1">{monthData.amount.toLocaleString()}₽</p>
            <div className="flex items-center gap-1 text-white/60 text-sm">
              <Calendar className="w-4 h-4" />
              <span>{monthData.appointments} записей</span>
            </div>
          </div>
          
          {/* Простая визуализация прогресса */}
          <div className="w-full bg-white/10 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-green-400 to-green-600 h-2 rounded-full shadow-[0_0_10px_rgba(34,197,94,0.5)]"
              style={{ width: `${Math.min((monthData.amount / 100000) * 100, 100)}%` }}
            ></div>
          </div>
          <p className="text-xs text-white/60 mt-2">Цель: 100,000₽</p>
        </div>
      </FuturisticCard>

      {/* Годовая статистика */}
      <FuturisticCard glow className="p-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-blue-400" />
              <h3 className="text-white">Доход за год</h3>
            </div>
            <div className={`flex items-center gap-1 text-sm ${
              yearData.change >= 0 ? 'text-green-400' : 'text-red-400'
            }`}>
              {yearData.change >= 0 ? 
                <TrendingUp className="w-4 h-4" /> : 
                <TrendingDown className="w-4 h-4" />
              }
              <span>{Math.abs(yearData.change)}%</span>
            </div>
          </div>
          
          <div className="mb-4">
            <p className="text-2xl text-white mb-1">{yearData.amount.toLocaleString()}₽</p>
            <div className="flex items-center gap-1 text-white/60 text-sm">
              <Calendar className="w-4 h-4" />
              <span>{yearData.appointments} записей</span>
            </div>
          </div>
          
          {/* Простая визуализация прогресса */}
          <div className="w-full bg-white/10 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-blue-400 to-blue-600 h-2 rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]"
              style={{ width: `${Math.min((yearData.amount / 1200000) * 100, 100)}%` }}
            ></div>
          </div>
          <p className="text-xs text-white/60 mt-2">Цель: 1,200,000₽</p>
        </div>
      </FuturisticCard>
    </div>
  );
}