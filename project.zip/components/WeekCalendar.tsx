import { useState } from "react";
import { FuturisticCard } from "./FuturisticCard";
import { GlowButton } from "./GlowButton";
import { FullMonthCalendar } from "./FullMonthCalendar";
import { ChevronLeft, ChevronRight, Plus, Calendar } from "lucide-react";

interface TimeSlot {
  time: string;
  client?: string;
  service?: string;
  duration: number;
  price?: number;
}

interface CalendarDay {
  date: string;
  day: string;
  isToday: boolean;
  slots: TimeSlot[];
}

interface WeekCalendarProps {
  onNewAppointment?: () => void;
}

export function WeekCalendar({ onNewAppointment }: WeekCalendarProps) {
  const [currentWeek, setCurrentWeek] = useState(0);
  const [showMonthView, setShowMonthView] = useState(false);

  const goToPrevWeek = () => {
    setCurrentWeek(prev => prev - 1);
  };

  const goToNextWeek = () => {
    setCurrentWeek(prev => prev + 1);
  };

  const getCurrentWeekDates = () => {
    const today = new Date();
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay() + 1 + (currentWeek * 7)); // Понедельник
    
    const weekDates = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(weekStart);
      date.setDate(weekStart.getDate() + i);
      weekDates.push(date);
    }
    return weekDates;
  };

  const weekDates = getCurrentWeekDates();
  const weekStartDate = weekDates[0];
  const weekEndDate = weekDates[6];
  
  // Мок-данные для недели
  const weekDays: CalendarDay[] = [
    {
      date: "18",
      day: "ПН",
      isToday: false,
      slots: [
        { time: "10:00", client: "Анна К.", service: "Стрижка", duration: 60, price: 2000 },
        { time: "14:00", duration: 60 },
        { time: "16:00", client: "Марк С.", service: "Окрашивание", duration: 120, price: 4500 }
      ]
    },
    {
      date: "19",
      day: "ВТ",
      isToday: true,
      slots: [
        { time: "09:00", duration: 60 },
        { time: "11:00", client: "Елена П.", service: "Маникюр", duration: 90, price: 1500 },
        { time: "15:00", duration: 60 },
        { time: "17:00", client: "Игорь Д.", service: "Стрижка", duration: 60, price: 2000 }
      ]
    },
    {
      date: "20",
      day: "СР",
      isToday: false,
      slots: [
        { time: "10:00", duration: 60 },
        { time: "12:00", client: "Ольга Н.", service: "Укладка", duration: 90, price: 2500 },
        { time: "16:00", duration: 60 }
      ]
    },
    {
      date: "21",
      day: "ЧТ",
      isToday: false,
      slots: [
        { time: "09:00", client: "Петр М.", service: "Стрижка", duration: 60, price: 2000 },
        { time: "13:00", duration: 60 },
        { time: "15:00", duration: 60 }
      ]
    },
    {
      date: "22",
      day: "ПТ",
      isToday: false,
      slots: [
        { time: "10:00", duration: 60 },
        { time: "12:00", duration: 60 },
        { time: "14:00", client: "София В.", service: "Маникюр", duration: 90, price: 1500 },
        { time: "17:00", client: "Алекс Р.", service: "Стрижка", duration: 60, price: 2000 }
      ]
    },
    {
      date: "23",
      day: "СБ",
      isToday: false,
      slots: [
        { time: "11:00", client: "Мария Л.", service: "Окрашивание", duration: 120, price: 4500 },
        { time: "15:00", duration: 60 },
        { time: "17:00", duration: 60 }
      ]
    },
    {
      date: "24",
      day: "ВС",
      isToday: false,
      slots: [
        { time: "12:00", duration: 60 },
        { time: "14:00", duration: 60 }
      ]
    }
  ];

  const handleDateSelect = (date: Date) => {
    console.log("Selected date:", date);
    setShowMonthView(false);
  };

  return (
    <>
      <FullMonthCalendar 
        isOpen={showMonthView}
        onClose={() => setShowMonthView(false)}
        onDateSelect={handleDateSelect}
      />
      
      <div className="space-y-4">
      {/* Заголовок календаря */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl text-white">
            {weekStartDate.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}
          </h2>
          <p className="text-white/60 text-sm">
            {weekStartDate.getDate()} - {weekEndDate.getDate()} {weekEndDate.toLocaleDateString('ru-RU', { month: 'long' })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowMonthView(true)}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            title="Показать месяц"
          >
            <Calendar className="w-4 h-4 text-white" />
          </button>
          <button 
            onClick={goToPrevWeek}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            title="Предыдущая неделя"
          >
            <ChevronLeft className="w-4 h-4 text-white" />
          </button>
          <button 
            onClick={goToNextWeek}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            title="Следующая неделя"
          >
            <ChevronRight className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>

      {/* Дни недели */}
      <div className="grid grid-cols-7 gap-2">
        {weekDays.map((day, index) => (
          <FuturisticCard 
            key={index}
            className={`p-2 text-center cursor-pointer hover:bg-white/5 transition-colors ${day.isToday ? 'border-white/40 shadow-[0_0_15px_rgba(255,255,255,0.2)]' : ''}`}
            onClick={() => console.log(`Selected day: ${day.date}`)}
          >
            <div className={`text-xs mb-1 ${day.isToday ? 'text-white' : 'text-white/60'}`}>
              {day.day}
            </div>
            <div className={`text-sm ${day.isToday ? 'text-white' : 'text-white/80'}`}>
              {day.date}
            </div>
          </FuturisticCard>
        ))}
      </div>

      {/* Слоты времени для сегодня */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-white">
            {currentWeek === 0 ? 
              `Сегодня (${new Date().getDate()} ${new Date().toLocaleDateString('ru-RU', { month: 'long' })})` :
              `Неделя ${currentWeek > 0 ? '+' : ''}${currentWeek}`
            }
          </h3>
          <GlowButton 
            variant="secondary" 
            className="p-2 text-xs"
            onClick={onNewAppointment}
          >
            <Plus className="w-4 h-4" />
          </GlowButton>
        </div>
        
        <div className="space-y-2">
          {weekDays[1].slots.map((slot, index) => (
            <FuturisticCard 
              key={index} 
              className="p-3 cursor-pointer hover:bg-white/5 transition-colors"
              onClick={() => slot.client ? console.log('Edit appointment:', slot) : onNewAppointment?.()}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="text-white/60 text-sm w-12">{slot.time}</div>
                  {slot.client ? (
                    <div>
                      <p className="text-white text-sm">{slot.client}</p>
                      <p className="text-white/60 text-xs">{slot.service}</p>
                    </div>
                  ) : (
                    <div className="text-white/40 text-sm hover:text-white/60 transition-colors">
                      Свободно - нажмите для записи
                    </div>
                  )}
                </div>
                {slot.price && (
                  <div className="text-right">
                    <p className="text-white text-sm">{slot.price}₽</p>
                    <p className="text-white/60 text-xs">{slot.duration} мин</p>
                  </div>
                )}
              </div>
            </FuturisticCard>
          ))}
        </div>
      </div>
      </div>
    </>
  );
}