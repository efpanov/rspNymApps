import { Button } from "./ui/button";
import { cn } from "./ui/utils";

interface GlowButtonProps {
  children: React.ReactNode;
  variant?: "primary" | "secondary";
  className?: string;
  onClick?: () => void;
}

export function GlowButton({ children, variant = "primary", className, onClick }: GlowButtonProps) {
  const baseClasses = "relative overflow-hidden transition-all duration-300 border-0";
  
  const variantClasses = {
    primary: `
      bg-white text-black hover:bg-gray-100
      shadow-[0_0_20px_rgba(255,255,255,0.3)]
      hover:shadow-[0_0_30px_rgba(255,255,255,0.5)]
      before:absolute before:inset-0 before:bg-gradient-to-r 
      before:from-transparent before:via-white/20 before:to-transparent
      before:translate-x-[-100%] hover:before:translate-x-[100%]
      before:transition-transform before:duration-700
    `,
    secondary: `
      bg-transparent text-white border border-white/30
      shadow-[0_0_15px_rgba(255,255,255,0.2)]
      hover:shadow-[0_0_25px_rgba(255,255,255,0.4)]
      hover:bg-white/10
    `
  };

  return (
    <Button
      className={cn(baseClasses, variantClasses[variant], className)}
      onClick={onClick}
    >
      {children}
    </Button>
  );
}